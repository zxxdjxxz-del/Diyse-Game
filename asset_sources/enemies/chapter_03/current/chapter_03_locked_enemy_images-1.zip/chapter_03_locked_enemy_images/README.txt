Chapter 3 — Locked Enemy Images

This folder intentionally contains only Chapter-3-specific/new locked enemy art.

Included:
01 Maul Construct
02 Flame Construct
03 Flash Drone
04 Blade Drone
05 Ruin Spider
06 Memory Construct
07 Authority Construct

Not duplicated here:
- Construct — locked image already lives with Chapter 1 enemy assets.
- Shield Construct — locked image already lives with Chapter 1 enemy assets.
- Arcdrift — locked image already lives with Chapter 2 enemy assets.

Scriptshade is Chapter-3-specific and belongs in this folder as well; its locked image already exists in the repo but is not mounted in this runtime, so it has not been substituted with a different image.
